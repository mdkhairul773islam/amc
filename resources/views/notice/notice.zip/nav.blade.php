<!-- body nav start -->
<div class="body_nav">
    <ul>
        <li><a class="addNotice" href="{{route('admin.notice.create')}}">Add Notice</a></li>
        <li><a class="allNotice" href="{{route('admin.notice')}}" >All Notice</a></li>
    </ul>
</div>
<!-- body nav start -->
