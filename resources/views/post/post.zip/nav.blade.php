<!-- body nav start -->
<div class="body_nav">
    <ul>
        <li><a class="addPost" href="{{route('admin.post.create')}}">Add Post</a></li>
        <li><a class="allPost" href="{{route('admin.post')}}" >All Post</a></li>
    </ul>
</div>
<!-- body nav start -->
